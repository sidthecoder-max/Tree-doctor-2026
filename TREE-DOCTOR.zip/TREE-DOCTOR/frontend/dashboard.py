"""
dashboard.py - Streamlit dashboard.

Run:  streamlit run frontend/dashboard.py        (from repo root)

Modes (sidebar)
    Live    : pulls readings from the Flask backend (ESP32 -> /ingest) and calls /diagnose
    Demo    : uses SIMULATED data (signal_processing/synthetic_data.py) - clearly labelled in the UI
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import requests
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.pipeline import make_agent, process_signals, run_pipeline  # noqa: E402
from computer_vision.disease_classification import predict  # noqa: E402
from signal_processing.synthetic_data import generate  # noqa: E402

st.set_page_config(page_title="Tree Doctor", page_icon="🌳", layout="wide")
st.title("🌳 Tree Doctor - agentic tree-health monitoring")

mode = st.sidebar.radio("Data source", ["Demo (simulated)", "Live (backend)"])
backend = st.sidebar.text_input("Backend URL", "http://localhost:5000")
leaf_file = st.sidebar.file_uploader("Leaf photo (optional)", type=["jpg", "jpeg", "png"])
run = st.sidebar.button("Run diagnosis", type="primary")

if "agent_memory" not in st.session_state:
    st.session_state.agent_memory = []

# ------------------------------------------------------------------ data ------------
if mode.startswith("Demo"):
    st.warning("DEMO MODE: data below is simulated, not measured.")
    df = generate(days=3, seed=3)[["t", "soil", "temp", "hum"]]
else:
    try:
        df = pd.DataFrame(requests.get(f"{backend}/readings", params={"n": 2000}, timeout=5).json())
    except Exception as e:
        st.error(f"Backend not reachable: {e}")
        st.stop()
    if len(df) < 30:
        st.info("Waiting for readings from the ESP32 (need >= 30).")
        st.stop()

d, iv = process_signals(df)
c1, c2, c3 = st.columns(3)
c1.metric("Soil moisture (filtered)", f"{d['soil_f'].iloc[-1]:.1f} %")
c2.metric("Temperature", f"{d['temp_f'].iloc[-1]:.1f} °C")
c3.metric("Humidity", f"{d['hum_f'].iloc[-1]:.1f} %")

fig, ax = plt.subplots(figsize=(10, 3.2))
tt = (d["t"] - d["t"].iloc[0]) / 3600
ax.plot(tt, d["soil"], lw=.5, alpha=.5, label="raw")
ax.plot(tt, d["soil_f"], lw=1.6, label="filtered")
ax.scatter(tt[d["anomaly_any"]], d["soil"][d["anomaly_any"]], s=14, c="red", label="anomaly", zorder=3)
ax.set_xlabel("hours"); ax.set_ylabel("soil moisture (%)"); ax.legend(loc="upper right")
st.pyplot(fig)

# ------------------------------------------------------------------ diagnosis -------
if run:
    leaf = None
    if leaf_file is not None:
        buf = np.frombuffer(leaf_file.read(), np.uint8)
        import cv2
        img = cv2.imdecode(buf, cv2.IMREAD_COLOR)
        st.image(cv2.cvtColor(img, cv2.COLOR_BGR2RGB), caption="Uploaded leaf", width=260)
        leaf = predict(img)
        st.write("**Leaf analysis:**", leaf["label"], f"({leaf['confidence']:.0%}, {leaf['source']})")
    agent = make_agent(df, leaf_provider=(lambda: leaf) if leaf else None)
    agent.memory = st.session_state.agent_memory
    res, _ = run_pipeline(df, agent)
    st.subheader(f"Diagnosis: {res['diagnosis'].replace('_', ' ')}  ({res['confidence']:.0%})")
    st.write(res["explanation"])
    st.markdown("#### Recommendations")
    for r in res["recommendations"]:
        st.write(f"- **[{r['urgency']}]** {r['action']}")
    with st.expander("Agent reasoning trace"):
        st.json(res["trace"])
    st.bar_chart(pd.Series(res["posterior"]).sort_values())

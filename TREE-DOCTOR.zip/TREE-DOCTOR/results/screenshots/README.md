# Implementation evidence

Everything here was produced by running this repository on SIMULATED sensor data and SYNTHETIC leaf images.
Nothing comes from real hardware or real leaf photos yet.

| # | Evidence | File | Status |
|---|---|---|---|
| 1 | ESP32 and connected sensors | - | Not captured (firmware written, board not flashed) |
| 2 | Live sensor readings | - | Not captured. Backend ingest tested with simulated POSTs: `results/evidence/03_backend_api_test_log.txt` |
| 3 | Soil-moisture time series | `03_soil_moisture_timeseries.png`, `03b_demo_signals.png` | Provided (simulated) |
| 4 | Signal filtering output | `04_signal_filtering.png` | Provided (simulated) |
| 5 | Anomaly detection | `05_anomaly_detection.png` | Provided (simulated) |
| 6 | Leaf image uploaded | `06b_dashboard_before_diagnosis.png`, `06_07_leaf_analysis.png` | Provided (synthetic leaf) |
| 7 | Leaf classification | `06_07_leaf_analysis.png` | Provided (rule-based) |
| 8 | AI diagnosis | `08_agent_belief_update.png`, `../evidence/02_demo_*.txt` | Provided |
| 9 | Recommendations | `../evidence/02_demo_*.txt`, dashboard screenshot | Provided |
| 10 | Final dashboard | `10_final_dashboard_scorched_leaf.png` | Provided (demo mode) |

Logs: `results/evidence/` (experiment run, four demo runs, backend API test).
Reproduce: `python results/run_experiments.py`, `python demo.py`, `streamlit run frontend/dashboard.py`.
If you capture real hardware evidence, add it here and update the Status column.

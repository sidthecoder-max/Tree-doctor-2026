"""
run_experiments.py - reproduces every number and graph that comes from code (no hardware needed).

    python results/run_experiments.py

Outputs
    results/metrics.json
    results/graphs/soil_timeseries.png, signal_filtering.png, anomaly_detection.png, agent_belief_update.png

What is measured here (ALL on simulated data / hand-written scenarios - say so in the report):
    A. Noise reduction   RMSE vs known clean signal: raw, moving-average baseline, our pipeline
    B. Anomaly detection event-level precision/recall/F1 per anomaly type, 5 seeds; baseline = global
                         z-score on first difference
    C. Compute cost      wall time and peak memory to process 7 days of 1/min data
    D. Agent             scenario test of decision logic vs a soil-threshold-only baseline
Leaf-classifier and real-sensor metrics are NOT produced here: run disease_classification.py train and
measure your hardware.
"""
import json
import sys
import time
import tracemalloc
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from agentic_ai.decision_engine import evidence_from_features, evidence_from_leaf, posterior  # noqa: E402
from agentic_ai.diagnosis_agent import DiagnosisAgent, Tools  # noqa: E402
from backend.pipeline import process_signals  # noqa: E402
from signal_processing.anomaly_detection import event_prf  # noqa: E402
from signal_processing.data_filtering import fill_gaps, moving_average  # noqa: E402
from signal_processing.synthetic_data import generate  # noqa: E402

OUT = ROOT / "results"
(OUT / "graphs").mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"figure.dpi": 140, "axes.spines.top": False, "axes.spines.right": False})
metrics: dict = {"note": "All numbers are on SIMULATED data or hand-written scenarios."}


def rmse(a, b):
    return float(np.sqrt(np.nanmean((np.asarray(a) - np.asarray(b)) ** 2)))


# ------------------------------------------------------------------ A. noise reduction -
df = generate(days=7, seed=0)
d, iv = process_signals(df[["t", "soil", "temp", "hum"]], 60.0)
truth = df["true_clean"].to_numpy()
raw_filled = fill_gaps(df["soil"].to_numpy())
clean_noise_only = ~(df["is_spike"] | df["is_flatline"]).to_numpy()
ma5, ma15 = moving_average(raw_filled, 5), moving_average(raw_filled, 15)
metrics["A_noise_reduction"] = {
    "rmse_all_samples": {"raw": rmse(raw_filled, truth), "moving_avg_5": rmse(ma5, truth),
                         "moving_avg_15": rmse(ma15, truth), "tree_doctor_pipeline": rmse(d["soil_f"], truth)},
    "rmse_noise_only_samples": {"raw": rmse(raw_filled[clean_noise_only], truth[clean_noise_only]),
                                "moving_avg_5": rmse(ma5[clean_noise_only], truth[clean_noise_only]),
                                "moving_avg_15": rmse(ma15[clean_noise_only], truth[clean_noise_only]),
                                "tree_doctor_pipeline": rmse(d["soil_f"].to_numpy()[clean_noise_only],
                                                             truth[clean_noise_only])},
}
a = metrics["A_noise_reduction"]["rmse_all_samples"]
metrics["A_noise_reduction"]["rmse_reduction_pct_vs_raw"] = 100 * (1 - a["tree_doctor_pipeline"] / a["raw"])

# ------------------------------------------------------------------ B. anomaly detection
def zscore_baseline(raw):
    r = fill_gaps(raw)
    dd = np.diff(r, prepend=r[0])
    return np.abs(dd - dd.mean()) > 3 * dd.std()


per_seed = {"spike": [], "flatline": [], "drop": [], "baseline_any": [], "tree_doctor_any": []}
for seed in range(5):
    g = generate(days=7, seed=seed)
    dd, _ = process_signals(g[["t", "soil", "temp", "hum"]], 60.0)
    per_seed["spike"].append(event_prf(g["is_spike"], dd["anomaly_spike"], tol=2))
    per_seed["flatline"].append(event_prf(g["is_flatline"], dd["anomaly_flatline"], tol=5))
    per_seed["drop"].append(event_prf(g["is_drop"], dd["anomaly_drop"], tol=15))
    any_true = (g["is_spike"] | g["is_flatline"] | g["is_drop"]).to_numpy()
    per_seed["baseline_any"].append(event_prf(any_true, zscore_baseline(g["soil"].to_numpy()), tol=15))
    per_seed["tree_doctor_any"].append(event_prf(any_true, dd["anomaly_any"], tol=15))
agg = {}
for k, v in per_seed.items():
    if isinstance(v, list):
        agg[k] = {m: float(np.nanmean([x[m] for x in v])) for m in ("precision", "recall", "f1")}
        agg[k]["true_events_total"] = int(sum(x["true_events"] for x in v))
metrics["B_anomaly_detection_mean_of_5_seeds"] = agg

# ------------------------------------------------------------------ C. compute cost ----
times, peaks = [], []
for _ in range(3):
    tracemalloc.start()
    t0 = time.perf_counter()
    process_signals(df[["t", "soil", "temp", "hum"]], 60.0)
    times.append(time.perf_counter() - t0)
    peaks.append(tracemalloc.get_traced_memory()[1] / 1e6)
    tracemalloc.stop()
metrics["C_compute_cost_7days_10080_samples"] = {"seconds_mean": float(np.mean(times)),
                                                  "peak_python_memory_MB": float(np.mean(peaks))}

# ------------------------------------------------------------------ D. agent scenarios -
def feats(**kw):
    base = dict(n_samples=500, soil_now=50.0, soil_mean_24h=50.0, soil_slope_per_h=0.0, hours_to_dry=float("nan"),
                n_irrigations=0, hours_since_irrigation=float("nan"), hours_above_wet=0.0, temp_now=28.0,
                temp_max_24h=30.0, hum_now=60.0, hum_mean_24h=60.0, anomaly_fraction=0.0, flatline=False, quality=1.0)
    base.update(kw)
    return base


def leaf(label="healthy", y=0.02, b=0.02, s=0.0, n=0):
    return {"label": label, "confidence": 0.8, "source": "rules",
            "symptoms": {"yellow_fraction": y, "brown_fraction": b, "spot_fraction": s, "spot_count": n}}


SCEN = [  # name, features, leaf, expected
    ("dry soil + scorched leaf", feats(soil_now=15), leaf("necrosis", b=0.2), "drought_stress"),
    ("saturated soil + yellow leaf", feats(soil_now=85, hours_above_wet=20), leaf("chlorosis", y=0.3), "overwatering"),
    ("humid + leaf spots", feats(hum_mean_24h=88), leaf("leaf_spot", s=0.08, n=12), "fungal_disease"),
    ("normal soil + yellow leaf", feats(), leaf("chlorosis", y=0.35), "nutrient_deficiency"),
    ("heat wave + scorched leaf", feats(soil_now=45, temp_max_24h=41), leaf("necrosis", b=0.18), "heat_stress"),
    ("all normal", feats(), leaf(), "healthy"),
    ("stuck (flatline) sensor", feats(soil_now=52, flatline=True), leaf(), "sensor_fault"),
]


def baseline(f):
    return "drought_stress" if f["soil_now"] < 25 else "overwatering" if f["soil_now"] > 75 else "healthy"


rows, ok_agent, ok_base = [], 0, 0
for name, f, lf, exp in SCEN:
    ag = DiagnosisAgent(tools=Tools(request_leaf_image=lambda lf=lf: lf))
    # agent starts WITHOUT the leaf image and must decide to request it
    r = ag.run(f, leaf=None)
    called = [t["action"] for t in r["trace"] if t["action"] != "finalize"]
    ok_agent += r["diagnosis"] == exp
    ok_base += baseline(f) == exp
    rows.append({"scenario": name, "expected": exp, "agent": r["diagnosis"], "agent_conf": round(r["confidence"], 3),
                 "tools_called": called, "baseline": baseline(f)})
metrics["D_agent_scenarios"] = {"n": len(SCEN), "agent_correct": ok_agent, "baseline_correct": ok_base, "rows": rows,
                                "caveat": "scenarios and likelihood table are authored by the team: a logic test, not field validation"}

# Needs-human behaviour: ambiguous case, no leaf available
ag = DiagnosisAgent(tools=Tools())
r = ag.run(feats(soil_now=55, hum_mean_24h=85), None)
metrics["D_ambiguous_no_leaf"] = {"diagnosis": r["diagnosis"], "confidence": round(r["confidence"], 3),
                                  "needs_human": r["needs_human"]}

# Adaptation via memory: advice 'irrigate', soil does not respond
ag = DiagnosisAgent(tools=Tools(request_leaf_image=lambda: leaf("necrosis", b=0.2)))
r1 = ag.run(feats(soil_now=15, n_samples=500), None)
r2 = ag.run(feats(soil_now=16, n_samples=800), None)
metrics["D_memory_adaptation"] = {"episode1": {"diagnosis": r1["diagnosis"], "confidence": round(r1["confidence"], 3)},
                                  "episode2_soil_did_not_rise": {"diagnosis": r2["diagnosis"],
                                                                 "confidence": round(r2["confidence"], 3),
                                                                 "evidence_irrigation_ineffective":
                                                                     r2["evidence"].get("irrigation_ineffective")}}

# Quality-triggered resample
ag = DiagnosisAgent(tools=Tools(request_resample=lambda: feats(soil_now=50, quality=0.95),
                                request_leaf_image=lambda: leaf()))
r = ag.run(feats(quality=0.4), None)
metrics["D_quality_resample"] = {"trace_actions": [t["action"] for t in r["trace"]]}

# ------------------------------------------------------------------ graphs --------------
hrs = df["t"].to_numpy() / 3600
fig, ax = plt.subplots(figsize=(10, 3.4))
ax.plot(hrs, df["soil"], lw=.4, c="#9aa5a0", label="raw sensor (simulated)")
ax.plot(hrs, d["soil_f"], lw=1.3, c="#1f6f4a", label="filtered (Tree Doctor)")
ax.plot(hrs, truth, lw=.9, c="#d98324", ls="--", label="ground truth")
ax.set_xlabel("time (h)"); ax.set_ylabel("soil moisture (%)"); ax.legend(ncol=3, loc="upper right", fontsize=8)
ax.set_title("Soil-moisture time series - 7 days, simulated")
fig.tight_layout(); fig.savefig(OUT / "graphs" / "soil_timeseries.png"); plt.close(fig)

lo, hi = 30 * 60, 34 * 60   # window around first irrigation
fig, ax = plt.subplots(figsize=(10, 3.4))
h2 = hrs[lo:hi]
ax.plot(h2, df["soil"].to_numpy()[lo:hi], lw=.6, c="#9aa5a0", label="raw")
ax.plot(h2, ma15[lo:hi], lw=1.2, c="#4c78a8", label="moving average (15) baseline")
ax.plot(h2, d["soil_f"].to_numpy()[lo:hi], lw=1.6, c="#1f6f4a", label="Hampel + Butterworth")
ax.plot(h2, truth[lo:hi], lw=.9, c="#d98324", ls="--", label="ground truth")
ax.set_xlabel("time (h)"); ax.set_ylabel("soil moisture (%)"); ax.legend(fontsize=8)
ax.set_title("Signal filtering around an irrigation event")
fig.tight_layout(); fig.savefig(OUT / "graphs" / "signal_filtering.png"); plt.close(fig)

fig, ax = plt.subplots(figsize=(10, 3.4))
ax.plot(hrs, df["soil"], lw=.4, c="#9aa5a0")
for col, c, lab in (("anomaly_spike", "#d62728", "spike"), ("anomaly_flatline", "#9467bd", "flatline"),
                    ("anomaly_drop", "#ff7f0e", "sudden drop")):
    m = d[col].to_numpy()
    ax.scatter(hrs[m], df["soil"].to_numpy()[m], s=8, c=c, label=f"detected {lab}", zorder=3)
ax.set_xlabel("time (h)"); ax.set_ylabel("soil moisture (%)"); ax.legend(ncol=3, fontsize=8)
ax.set_title("Anomaly detection (seed 0, simulated)")
fig.tight_layout(); fig.savefig(OUT / "graphs" / "anomaly_detection.png"); plt.close(fig)

f3, lf3 = SCEN[2][1], SCEN[2][2]
ev_before = evidence_from_features(f3)
ev_after = {**ev_before, **evidence_from_leaf(lf3)}
pb, pa = posterior(ev_before), posterior(ev_after)
names = sorted(pb, key=lambda k: pa[k])
fig, ax = plt.subplots(figsize=(8, 3.6))
y = np.arange(len(names))
ax.barh(y - .2, [pb[k] for k in names], .4, label="sensors only", color="#9aa5a0")
ax.barh(y + .2, [pa[k] for k in names], .4, label="after agent requests leaf image", color="#1f6f4a")
ax.set_yticks(y, [n.replace("_", " ") for n in names]); ax.set_xlabel("belief"); ax.legend(fontsize=8)
ax.set_title("Agent belief update (humid + leaf-spot scenario)")
fig.tight_layout(); fig.savefig(OUT / "graphs" / "agent_belief_update.png"); plt.close(fig)

(OUT / "metrics.json").write_text(json.dumps(metrics, indent=2, default=float))
print(json.dumps(metrics, indent=2, default=float))

"""
Write a simulated sensor CSV (with ground-truth columns) to datasets/synthetic_sensor_data.csv

    python datasets/generate_synthetic_data.py --days 7 --seed 0

Simulation model is documented in signal_processing/synthetic_data.py. This is SIMULATED data.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from signal_processing.synthetic_data import generate  # noqa: E402

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=7)
    ap.add_argument("--seed", type=int, default=0)
    a = ap.parse_args()
    out = Path(__file__).with_name("synthetic_sensor_data.csv")
    generate(days=a.days, seed=a.seed).to_csv(out, index=False)
    print("wrote", out)

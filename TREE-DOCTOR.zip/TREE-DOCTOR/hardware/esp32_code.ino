/*
 * Tree Doctor - ESP32 firmware
 * Sensors : capacitive soil moisture (analog, GPIO34), DHT22 temp/humidity (GPIO4)
 * Output  : JSON line on Serial (115200) AND HTTP POST to the Flask backend /ingest
 * Libs    : "DHT sensor library" (Adafruit) + "Adafruit Unified Sensor"; WiFi/HTTPClient ship with ESP32 core.
 *
 * Edit WIFI_*, BACKEND_URL and the two calibration values (see sensor_configuration.md).
 */
#include <WiFi.h>
#include <HTTPClient.h>
#include "DHT.h"

const char* WIFI_SSID   = "YOUR_WIFI";
const char* WIFI_PASS   = "YOUR_PASSWORD";
const char* BACKEND_URL = "http://192.168.1.50:5000/ingest";   // laptop running backend/app.py

#define SOIL_PIN 34
#define DHT_PIN  4
#define DHT_TYPE DHT22

// Raw ADC readings measured by YOU: probe in dry air and probe in water (see sensor_configuration.md)
const int ADC_DRY = 3200;   // 0 %   (example value - calibrate!)
const int ADC_WET = 1400;   // 100 % (example value - calibrate!)

const uint32_t SAMPLE_PERIOD_MS = 5000;
const int OVERSAMPLE = 16;          // average 16 ADC reads to reduce quantisation noise

DHT dht(DHT_PIN, DHT_TYPE);

float readSoilPercent() {
  long acc = 0;
  for (int i = 0; i < OVERSAMPLE; i++) { acc += analogRead(SOIL_PIN); delay(5); }
  float raw = acc / (float)OVERSAMPLE;
  float pct = (raw - ADC_DRY) * 100.0f / (ADC_WET - ADC_DRY);
  return constrain(pct, 0.0f, 100.0f);
}

void connectWiFi() {
  WiFi.begin(WIFI_SSID, WIFI_PASS);
  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && millis() - t0 < 15000) delay(250);
}

void setup() {
  Serial.begin(115200);
  analogReadResolution(12);
  dht.begin();
  connectWiFi();
}

void loop() {
  float soil = readSoilPercent();
  float temp = dht.readTemperature();
  float hum  = dht.readHumidity();

  if (isnan(temp) || isnan(hum)) {           // DHT dropout: skip (backend handles gaps)
    Serial.println("{\"error\":\"dht_read_failed\"}");
    delay(SAMPLE_PERIOD_MS);
    return;
  }

  char body[96];
  snprintf(body, sizeof(body), "{\"soil\":%.2f,\"temp\":%.2f,\"hum\":%.2f}", soil, temp, hum);
  Serial.println(body);

  if (WiFi.status() != WL_CONNECTED) connectWiFi();
  if (WiFi.status() == WL_CONNECTED) {
    HTTPClient http;
    http.begin(BACKEND_URL);
    http.addHeader("Content-Type", "application/json");
    http.POST((uint8_t*)body, strlen(body));
    http.end();
  }
  delay(SAMPLE_PERIOD_MS);
}

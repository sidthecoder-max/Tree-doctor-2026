# Sensor configuration

## Bill of materials (edit to match what you actually used)
| Part | Role | ESP32 pin |
|---|---|---|
| ESP32 DevKit | MCU + Wi-Fi | - |
| Capacitive soil-moisture sensor v1.2 | soil moisture (analog) | GPIO34 (ADC1) |
| DHT22 (AM2302) | air temperature + humidity | GPIO4 (10 k pull-up to 3V3) |

Power both sensors from 3V3. Use ADC1 pins only (GPIO32-39) - ADC2 is unusable while Wi-Fi is on.

## Calibration (soil moisture)
1. Probe in **dry air** -> note the raw ADC average -> `ADC_DRY`.
2. Probe in a **glass of water** up to the line -> note raw ADC -> `ADC_WET`.
3. Put both numbers in `esp32_code.ino`. Output is then a *relative* 0-100 % wetness index,
   **not** true volumetric water content unless checked against a gravimetric reference.

## Sampling
- Firmware: 16x ADC oversampling, one reading every 5 s, sent over Wi-Fi (HTTP POST) and printed on Serial.
- Backend resamples to a uniform grid before filtering.

## Accuracy check (do this if you have time - only report what you measure)
- Take 5-10 soil samples at different wetness; record sensor %, then dry in an oven/sun and compute gravimetric
  moisture, OR compare against a handheld moisture meter.
- Report MAE / correlation (R^2) between sensor and reference in the report. If no reference exists, write
  "not measured" - do not estimate.

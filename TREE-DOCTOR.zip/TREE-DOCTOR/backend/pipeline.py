"""
pipeline.py - glue: raw readings -> filtered signals -> anomalies -> features -> agent diagnosis.
Used by the Flask backend, the Streamlit dashboard (demo mode) and the experiment script.
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from agentic_ai.diagnosis_agent import DiagnosisAgent, Tools  # noqa: E402
from signal_processing.anomaly_detection import detect_anomalies  # noqa: E402
from signal_processing.data_filtering import clean_signal  # noqa: E402
from signal_processing.time_series import extract_features  # noqa: E402


def process_signals(df: pd.DataFrame, interval_s: Optional[float] = None) -> tuple[pd.DataFrame, float]:
    """df columns: t (s), soil, temp, hum. Adds *_f (filtered) and anomaly_* columns."""
    d = df.copy().reset_index(drop=True)
    interval_s = interval_s or float(np.median(np.diff(d["t"].to_numpy())))
    for col, short in (("soil", "soil_f"), ("temp", "temp_f"), ("hum", "hum_f")):
        d[short] = clean_signal(d[col].to_numpy(), interval_s)["filtered"]
    an = detect_anomalies(d["soil"].to_numpy(), d["soil_f"].to_numpy(), interval_s)
    d["anomaly_spike"], d["anomaly_flatline"] = an["spike"], an["flatline"]
    d["anomaly_drop"], d["anomaly_any"] = an["drop"], an["any"]
    return d, interval_s


def run_pipeline(df: pd.DataFrame, agent: DiagnosisAgent, leaf: Optional[dict] = None,
                 interval_s: Optional[float] = None) -> tuple[dict, pd.DataFrame]:
    d, interval_s = process_signals(df, interval_s)
    feats = extract_features(d, interval_s)
    return agent.run(feats, leaf), d


def make_agent(df_raw: pd.DataFrame, leaf_provider=None, interval_s: Optional[float] = None) -> DiagnosisAgent:
    """Agent whose request_resample re-processes the latest window and whose leaf tool is `leaf_provider`."""
    def resample():
        d, iv = process_signals(df_raw.tail(240), interval_s)   # re-read last ~4 h at native rate
        return extract_features(d, iv)
    return DiagnosisAgent(tools=Tools(request_resample=resample, request_leaf_image=leaf_provider))

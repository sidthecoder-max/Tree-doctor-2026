"""
app.py - Flask backend for Tree Doctor.

    POST /ingest     JSON {"soil":..,"temp":..,"hum":..,"t":<optional epoch s>}  (sent by the ESP32)
    GET  /readings   ?n=500   -> last n raw readings
    POST /diagnose   multipart: optional file field "leaf" (jpg/png) -> agent diagnosis JSON
    GET  /health

Run:  python backend/app.py        (from repo root, listens on :5000)
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
from flask import Flask, jsonify, request

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.pipeline import make_agent, run_pipeline  # noqa: E402
from computer_vision.disease_classification import predict  # noqa: E402

app = Flask(__name__)
READINGS: list[dict] = []
LOG = Path(__file__).resolve().parents[1] / "datasets" / "live_readings.csv"
AGENT_MEMORY: list = []          # persists across /diagnose calls so the agent can adapt


@app.get("/health")
def health():
    return {"status": "ok", "n_readings": len(READINGS)}


@app.post("/ingest")
def ingest():
    j = request.get_json(force=True)
    row = {"t": float(j.get("t", time.time())), "soil": float(j["soil"]),
           "temp": float(j["temp"]), "hum": float(j["hum"])}
    READINGS.append(row)
    LOG.parent.mkdir(exist_ok=True)
    pd.DataFrame([row]).to_csv(LOG, mode="a", header=not LOG.exists(), index=False)
    return {"ok": True, "n": len(READINGS)}


@app.get("/readings")
def readings():
    n = int(request.args.get("n", 500))
    return jsonify(READINGS[-n:])


@app.post("/diagnose")
def diagnose():
    if len(READINGS) < 30:
        return jsonify({"error": "need at least 30 readings"}), 400
    df = pd.DataFrame(READINGS)
    leaf_dict = None
    if "leaf" in request.files:
        buf = np.frombuffer(request.files["leaf"].read(), np.uint8)
        import cv2
        img = cv2.imdecode(buf, cv2.IMREAD_COLOR)
        leaf_dict = predict(img)
    agent = make_agent(df, leaf_provider=(lambda: leaf_dict) if leaf_dict else None)
    agent.memory = AGENT_MEMORY
    result, _ = run_pipeline(df, agent)
    result["leaf"] = leaf_dict
    result["features"] = {k: (None if isinstance(v, float) and v != v else v) for k, v in result["features"].items()}
    result["evidence"] = {k: v for k, v in result["evidence"].items()}
    return jsonify(result)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

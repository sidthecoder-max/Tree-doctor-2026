"""
anomaly_detection.py - detects three kinds of anomalies in soil-moisture style signals.

    spike     impulsive outlier on the raw signal (ADC glitch / bad read)  -> Hampel mask
    flatline  signal stuck at one value for >= min_len samples             -> sensor fault
    drop      sudden fall (> drop_thr points within `drop_win` samples)    -> leak / root damage /
                                                                              pulled probe; real drying is slow

Also provides event-level precision / recall / F1 so detection can be evaluated honestly.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from signal_processing.data_filtering import hampel, fill_gaps


def estimate_noise_sigma(raw) -> float:
    """Robust global noise estimate from the first difference (MAD / sqrt(2)); ignores spikes."""
    x = fill_gaps(raw)
    d = np.diff(x)
    return float(1.4826 * np.median(np.abs(d - np.median(d))) / np.sqrt(2))


def detect_spikes(raw, window: int = 11, n_sigmas: float = 4.0) -> np.ndarray:
    # Small-window local MAD underestimates noise, so the global noise level is used as a floor.
    # (Without it we measured ~1% false positives on simulated data.)
    sigma = max(estimate_noise_sigma(raw), 1e-3)
    _, mask = hampel(fill_gaps(raw), window=window, n_sigmas=n_sigmas, mad_floor=sigma)
    return mask


def detect_flatlines(raw, min_len: int = 30, eps: float = 1e-6) -> np.ndarray:
    """Mark runs of >= min_len consecutive (near-)identical samples."""
    x = pd.Series(np.asarray(raw, dtype=float)).ffill()
    same = x.diff().abs().fillna(1.0) <= eps
    run_id = (~same).cumsum()
    run_len = same.groupby(run_id).transform("sum") + 1  # +1 includes the run's first sample
    flat = (same & (run_len >= min_len)).to_numpy().copy()
    # include first sample of each flat run
    flat[:-1] |= flat[1:] & ~flat[:-1]
    return flat


def detect_drops(filtered, drop_win: int = 10, drop_thr: float = 6.0) -> np.ndarray:
    s = pd.Series(np.asarray(filtered, dtype=float))
    delta = s - s.shift(drop_win)
    return (delta < -drop_thr).fillna(False).to_numpy()


def detect_anomalies(raw, filtered, interval_s: float = 60.0) -> pd.DataFrame:
    """Return DataFrame with boolean columns spike, flatline, drop, any."""
    scale = 60.0 / interval_s  # keep window lengths ~ constant in minutes
    spikes = detect_spikes(raw, window=max(5, int(11 * scale) | 1))
    flat = detect_flatlines(raw, min_len=max(10, int(30 * scale)))
    drops = detect_drops(filtered, drop_win=max(3, int(10 * scale)))
    df = pd.DataFrame({"spike": spikes, "flatline": flat, "drop": drops})
    df["any"] = df.any(axis=1)
    return df


# ---------------------------------------------------------------- evaluation ---------
def _events(mask: np.ndarray):
    mask = np.asarray(mask, dtype=bool)
    edges = np.diff(np.r_[0, mask.astype(int), 0])
    starts, ends = np.where(edges == 1)[0], np.where(edges == -1)[0] - 1
    return list(zip(starts, ends))


def event_prf(true_mask, pred_mask, tol: int = 5) -> dict:
    """
    Event-level precision/recall/F1. A true event is detected if any predicted
    sample falls within `tol` samples of it; a predicted event is correct if it
    lies within `tol` samples of a true event.
    """
    t_ev, p_ev = _events(true_mask), _events(pred_mask)
    tp_true = sum(any(ps <= te + tol and pe >= ts - tol for ps, pe in p_ev) for ts, te in t_ev)
    tp_pred = sum(any(ts <= pe + tol and te >= ps - tol for ts, te in t_ev) for ps, pe in p_ev)
    recall = tp_true / len(t_ev) if t_ev else float("nan")
    precision = tp_pred / len(p_ev) if p_ev else float("nan")
    f1 = (2 * precision * recall / (precision + recall)
          if precision and recall and not np.isnan(precision + recall) else 0.0)
    return {"true_events": len(t_ev), "pred_events": len(p_ev),
            "precision": precision, "recall": recall, "f1": f1}

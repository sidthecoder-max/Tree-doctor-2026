"""
synthetic_data.py - physically-motivated SIMULATED sensor data with known ground truth.

IMPORTANT (disclosure): this is simulated data, not field data. It exists so that the signal
processing can be evaluated against a known clean signal and known injected anomalies.
Any number computed on it must be reported as "on synthetic data".

Model
    temp(t)  = 26 + 6 sin(2pi (h-9)/24)                       diurnal cycle
    hum(t)   = 60 - 20 sin(2pi (h-9)/24)
    soil     : dS/dt = -k(temp) (S - S_res)                   evaporation, faster when hot
               + irrigation events (+35 points over 10 min)
               + sudden-drop events (-12 points over 5 min)   (real anomaly: leak/pulled probe)
    raw      = soil + N(0, sigma) + spikes + flatline faults + random dropouts (NaN)
Labels returned: true_clean (ground truth), is_spike, is_flatline, is_drop
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def generate(days: int = 7, interval_s: int = 60, seed: int = 0, noise_sigma: float = 1.2,
             n_spikes: int = 25, n_flatlines: int = 3, n_drops: int = 3) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    n = int(days * 86400 / interval_s)
    t = np.arange(n) * interval_s
    h = t / 3600.0
    temp = 26 + 6 * np.sin(2 * np.pi * (h - 9) / 24) + rng.normal(0, 0.15, n)
    hum = 60 - 20 * np.sin(2 * np.pi * (h - 9) / 24) + rng.normal(0, 0.5, n)

    steps_10m = max(1, int(600 / interval_s))
    steps_5m = max(1, int(300 / interval_s))
    irrig_idx = list(range(int(30 * 3600 / interval_s), n - steps_10m, int(rng.integers(40, 56) * 3600 / interval_s)))
    drop_idx = sorted(rng.choice(np.arange(int(12 * 3600 / interval_s), n - 600, 1), n_drops, replace=False))

    soil = np.zeros(n)
    s, s_res = 70.0, 8.0
    add = np.zeros(n)
    for i in irrig_idx:
        add[i:i + steps_10m] += 35.0 / steps_10m
    is_drop = np.zeros(n, bool)
    for i in drop_idx:
        add[i:i + steps_5m] -= 12.0 / steps_5m
        is_drop[i:i + steps_5m] = True
    for i in range(n):
        k = 0.0006 * (1 + 0.04 * (temp[i] - 26)) * interval_s / 60.0 * 1.0
        s += -k * (s - s_res) + add[i]
        s = float(np.clip(s, 0, 100))
        soil[i] = s
    raw = soil + rng.normal(0, noise_sigma, n)

    is_spike = np.zeros(n, bool)
    for i in rng.choice(np.arange(60, n - 60), n_spikes, replace=False):
        raw[i] += rng.choice([-1, 1]) * rng.uniform(15, 30)
        is_spike[i] = True
    is_flat = np.zeros(n, bool)
    for _ in range(n_flatlines):
        L = int(rng.integers(60, 121) * 60 / interval_s)
        i = int(rng.integers(int(6 * 3600 / interval_s), n - L - 10))
        if is_flat[max(0, i - 30):i + L + 30].any() or is_spike[i:i + L].any() or is_drop[max(0, i - 30):i + L + 30].any():
            continue
        raw[i:i + L] = raw[i]
        is_flat[i:i + L] = True
    drop_mask = rng.random(n) < 0.005
    raw[drop_mask & ~is_flat & ~is_spike] = np.nan

    return pd.DataFrame({"t": t.astype(float), "soil": np.clip(raw, 0, 100), "temp": temp, "hum": hum,
                         "true_clean": soil, "is_spike": is_spike, "is_flatline": is_flat, "is_drop": is_drop})

"""
time_series.py - turns cleaned sensor streams into decision-ready features for the agent.

Features produced by extract_features():
    soil_now, soil_mean_24h, soil_slope_per_h (last 3 h, % per hour), hours_to_dry,
    hours_since_irrigation, n_irrigations, hours_above_wet, temp_now, temp_max_24h,
    hum_now, hum_mean_24h, anomaly_fraction, flatline, quality, n_samples
"""
from __future__ import annotations

import numpy as np
import pandas as pd

DRY_THRESHOLD = 25.0   # % volumetric-style moisture below which a tree is considered water stressed
WET_THRESHOLD = 75.0   # % above which soil is considered saturated


def to_uniform(df: pd.DataFrame, interval_s: float) -> pd.DataFrame:
    """Resample an irregular stream (column `t` in seconds) onto a uniform grid."""
    d = df.copy()
    d.index = pd.to_datetime(d["t"], unit="s")
    d = d.drop(columns=["t"]).resample(f"{int(interval_s)}s").mean()
    d = d.interpolate(limit=10)
    d.insert(0, "t", (d.index.astype("int64") // 10**9).astype(float))
    return d.reset_index(drop=True)


def rolling_slope(y, interval_s: float, window_s: float = 3 * 3600) -> float:
    """Least-squares slope (units per hour) over the trailing window."""
    n = max(3, int(window_s / interval_s))
    y = np.asarray(y, dtype=float)[-n:]
    y = y[~np.isnan(y)]
    if len(y) < 3:
        return float("nan")
    x = np.arange(len(y)) * interval_s / 3600.0
    return float(np.polyfit(x, y, 1)[0])


def detect_irrigation_events(soil_filtered, interval_s: float, rise_thr: float = 8.0,
                             win_s: float = 15 * 60) -> list[int]:
    """Indices where soil moisture rises by > rise_thr points within win_s (watering / rain)."""
    s = pd.Series(np.asarray(soil_filtered, dtype=float))
    k = max(1, int(win_s / interval_s))
    rising = ((s - s.shift(k)) > rise_thr).fillna(False).to_numpy()
    edges = np.diff(np.r_[0, rising.astype(int)])
    return list(np.where(edges == 1)[0])


def extract_features(df: pd.DataFrame, interval_s: float) -> dict:
    """df must contain soil_f, temp_f, hum_f (filtered) and optionally anomaly flags."""
    n = len(df)
    spd = int(24 * 3600 / interval_s)          # samples per day
    last24 = df.tail(spd)
    soil = df["soil_f"].to_numpy()
    f: dict = {"n_samples": n}
    f["soil_now"] = float(soil[-1]) if n else float("nan")
    f["soil_mean_24h"] = float(last24["soil_f"].mean()) if n else float("nan")
    f["soil_slope_per_h"] = rolling_slope(soil, interval_s)
    slope = f["soil_slope_per_h"]
    f["hours_to_dry"] = (max(0.0, (f["soil_now"] - DRY_THRESHOLD) / -slope)
                         if slope == slope and slope < -0.05 and f["soil_now"] > DRY_THRESHOLD else float("nan"))
    events = detect_irrigation_events(soil, interval_s)
    f["n_irrigations"] = len(events)
    f["hours_since_irrigation"] = ((n - 1 - events[-1]) * interval_s / 3600.0) if events else float("nan")
    wet_run = 0
    for v in soil[::-1]:
        if v > WET_THRESHOLD:
            wet_run += 1
        else:
            break
    f["hours_above_wet"] = wet_run * interval_s / 3600.0
    f["temp_now"] = float(df["temp_f"].iloc[-1]) if n else float("nan")
    f["temp_max_24h"] = float(last24["temp_f"].max()) if n else float("nan")
    f["hum_now"] = float(df["hum_f"].iloc[-1]) if n else float("nan")
    f["hum_mean_24h"] = float(last24["hum_f"].mean()) if n else float("nan")
    if "anomaly_any" in df:
        f["anomaly_fraction"] = float(last24["anomaly_any"].mean())
        f["flatline"] = bool(df["anomaly_flatline"].tail(int(3600 / interval_s)).mean() > 0.8)
    else:
        f["anomaly_fraction"], f["flatline"] = 0.0, False
    f["quality"] = float(1.0 - min(1.0, f["anomaly_fraction"] * 5)) if n >= 30 else 0.3
    return f

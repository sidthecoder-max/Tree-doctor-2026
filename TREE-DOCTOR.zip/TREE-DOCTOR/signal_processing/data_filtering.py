"""
data_filtering.py - noise removal for slow environmental sensor signals.

Pipeline used by Tree Doctor (applied per channel: soil moisture, temperature, humidity):
    1. fill_gaps()   - linear interpolation over dropped samples (NaN)
    2. hampel()      - robust spike removal (rolling median + MAD)
    3. lowpass()     - zero-phase Butterworth low-pass (offline) or EMA (streaming)

Why these choices
    * Capacitive soil probes and DHT sensors produce occasional impulsive outliers
      (ADC glitches, bad reads). A median-based Hampel filter removes them without
      smearing real steps such as irrigation events (a plain moving average would).
    * Soil moisture dynamics are hours long, so a low cut-off (~15 min period) removes
      measurement noise without distorting the physical signal.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy.signal import butter, filtfilt, lfilter


def fill_gaps(x, limit: int | None = None) -> np.ndarray:
    """Linearly interpolate NaN samples (sensor dropouts)."""
    s = pd.Series(np.asarray(x, dtype=float))
    s = s.interpolate(method="linear", limit=limit, limit_direction="both")
    return s.to_numpy()


def hampel(x, window: int = 11, n_sigmas: float = 3.0, mad_floor: float = 0.05):
    """
    Hampel identifier. Returns (cleaned, outlier_mask).
    A sample is an outlier if |x - rolling_median| > n_sigmas * 1.4826 * MAD.
    `mad_floor` stops the threshold collapsing to zero on flat segments.
    """
    s = pd.Series(np.asarray(x, dtype=float))
    med = s.rolling(window, center=True, min_periods=1).median()
    mad = (s - med).abs().rolling(window, center=True, min_periods=1).median() * 1.4826
    thr = n_sigmas * np.maximum(mad.to_numpy(), mad_floor)
    mask = (s - med).abs().to_numpy() > thr
    cleaned = np.where(mask, med.to_numpy(), s.to_numpy())
    return cleaned, mask


def moving_average(x, window: int = 5) -> np.ndarray:
    """Plain centred moving average - used as the BASELINE filter in experiments."""
    return pd.Series(np.asarray(x, dtype=float)).rolling(window, center=True, min_periods=1).mean().to_numpy()


def lowpass(x, fs_hz: float, cutoff_hz: float, order: int = 3, causal: bool = False) -> np.ndarray:
    """Butterworth low-pass. causal=False -> zero-phase (filtfilt); True -> real-time (lfilter)."""
    x = np.asarray(x, dtype=float)
    nyq = fs_hz / 2.0
    wn = min(cutoff_hz / nyq, 0.99)
    b, a = butter(order, wn, btype="low")
    if causal or len(x) <= 3 * max(len(a), len(b)):
        return lfilter(b, a, x)
    return filtfilt(b, a, x)


def ema(x, alpha: float = 0.2) -> np.ndarray:
    """Exponential moving average for streaming use on the backend."""
    return pd.Series(np.asarray(x, dtype=float)).ewm(alpha=alpha, adjust=False).mean().to_numpy()


def clean_signal(x, interval_s: float, cutoff_period_s: float = 900.0, hampel_window: int = 11,
                 n_sigmas: float = 3.0) -> dict:
    """
    Full cleaning pipeline for one channel.
    Returns dict(filtered, despiked, outlier_mask, gap_mask).
    """
    x = np.asarray(x, dtype=float)
    gap_mask = np.isnan(x)
    filled = fill_gaps(x)
    despiked, outlier_mask = hampel(filled, window=hampel_window, n_sigmas=n_sigmas)
    fs = 1.0 / interval_s
    filtered = lowpass(despiked, fs_hz=fs, cutoff_hz=1.0 / cutoff_period_s)
    return {"filtered": filtered, "despiked": despiked,
            "outlier_mask": outlier_mask, "gap_mask": gap_mask}

"""
demo.py - full Tree Doctor workflow in the terminal, no browser or hardware needed.

    python demo.py                         # simulated sensors + built-in sample leaf (spotted)
    python demo.py --leaf path/to/leaf.jpg # use your own leaf photo
    python demo.py --no-leaf               # sensors only; agent will ask for a leaf and say it has none
    python demo.py --csv datasets/live_readings.csv   # real readings logged by the backend

Saves results/graphs/demo_signals.png (use as a screenshot).
"""
import argparse
import sys
from pathlib import Path

import cv2
import matplotlib
import numpy as np
import pandas as pd

matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from backend.pipeline import make_agent, run_pipeline  # noqa: E402
from computer_vision.disease_classification import predict  # noqa: E402
from signal_processing.synthetic_data import generate  # noqa: E402


def sample_leaf(path: Path, kind: str = "scorched") -> Path:
    """Draw a synthetic leaf: scorched (brown edge burn), spotted (lesions) or healthy."""
    img = np.full((400, 400, 3), 255, np.uint8)
    cv2.ellipse(img, (200, 200), (150, 100), 20, 0, 360, (40, 150, 60), -1)
    rng = np.random.default_rng(1)
    if kind == "spotted":
        for _ in range(14):
            cv2.circle(img, (int(rng.integers(120, 280)), int(rng.integers(150, 250))), int(rng.integers(4, 8)), (20, 40, 90), -1)
    elif kind == "scorched":
        mask = np.zeros(img.shape[:2], np.uint8)
        cv2.ellipse(mask, (200, 200), (150, 100), 20, 0, 360, 255, -1)
        burn = np.zeros_like(mask)
        cv2.ellipse(burn, (200, 200), (150, 100), 20, 0, 360, 255, 28)   # thick outline = edge scorch
        img[(burn > 0) & (mask > 0)] = (30, 70, 120)                      # brown (BGR)
    path.parent.mkdir(exist_ok=True)
    cv2.imwrite(str(path), img)
    return path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--leaf")
    ap.add_argument("--no-leaf", action="store_true")
    ap.add_argument("--sample", choices=["scorched", "spotted", "healthy"], default="scorched",
                    help="which built-in synthetic leaf to use (default scorched = consistent with dry soil)")
    ap.add_argument("--csv")
    a = ap.parse_args()

    if a.csv:
        df = pd.read_csv(a.csv)[["t", "soil", "temp", "hum"]]
        print(f"[data] {len(df)} REAL readings from {a.csv}")
    else:
        df = generate(days=3, seed=3)[["t", "soil", "temp", "hum"]]
        print(f"[data] {len(df)} SIMULATED readings (3 days, 1/min)")

    leaf = None
    if not a.no_leaf:
        p = Path(a.leaf) if a.leaf else sample_leaf(ROOT / "datasets" / f"sample_leaf_{a.sample}.png", a.sample)
        leaf = predict(str(p))
        print(f"[leaf] {p.name}: {leaf['label']} ({leaf['confidence']:.0%}, {leaf['source']})")
        print(f"       symptoms: " + ", ".join(f"{k}={v:.2f}" for k, v in leaf["symptoms"].items()))

    agent = make_agent(df, leaf_provider=(lambda: leaf) if leaf else None)
    res, d = run_pipeline(df, agent)

    print("\n=== AGENT TRACE ===")
    for s in res["trace"]:
        print(f" step {s['step']}: believes {s['belief_top']} ({s['confidence']:.0%}) -> {s['action']}  {('('+s['why']+')') if s['why'] else ''}")
    print("\n=== DIAGNOSIS ===")
    print(f" {res['diagnosis'].replace('_', ' ').upper()}  ({res['confidence']:.0%} confidence)"
          + ("  [needs human inspection]" if res["needs_human"] else ""))
    print(" " + res["explanation"])
    print("\n=== RECOMMENDATIONS ===")
    for r in res["recommendations"]:
        print(f" [{r['urgency']:>6}] {r['action']}")

    fig, ax = plt.subplots(figsize=(10, 3.4))
    t = (d["t"] - d["t"].iloc[0]) / 3600
    ax.plot(t, d["soil"], lw=.5, alpha=.5, label="raw")
    ax.plot(t, d["soil_f"], lw=1.6, label="filtered")
    ax.scatter(t[d["anomaly_any"]], d["soil"][d["anomaly_any"]], s=14, c="red", label="anomaly", zorder=3)
    ax.set_xlabel("hours"); ax.set_ylabel("soil moisture (%)"); ax.legend()
    out = ROOT / "results" / "graphs" / "demo_signals.png"
    fig.tight_layout(); fig.savefig(out, dpi=140)
    print(f"\n[saved] {out}")


if __name__ == "__main__":
    main()

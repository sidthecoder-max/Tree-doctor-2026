"""
image_processing.py - converts a leaf image into (a) interpretable symptom fractions and
(b) a numeric feature vector for the classifier.

Symptom fractions (computed on leaf pixels only, HSV thresholds):
    yellow_fraction   chlorosis: yellowing tissue
    brown_fraction    necrosis / scorch: brown-dark tissue
    spot_fraction     discrete dark lesions (area of small connected dark blobs / leaf area)
    spot_count        number of such lesions

NOTE: the HSV thresholds are heuristic and lighting dependent; they should be re-tuned/validated
on your own photos. They are used as evidence for the agent, not as ground truth.
"""
from __future__ import annotations

import cv2
import numpy as np

from computer_vision.leaf_detection import load_image, segment_leaf


def symptom_fractions(bgr: np.ndarray, mask: np.ndarray) -> dict:
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    leaf = mask > 0
    area = max(int(leaf.sum()), 1)
    H, S, V = hsv[..., 0], hsv[..., 1], hsv[..., 2]

    yellow = leaf & (H >= 18) & (H <= 34) & (S > 70) & (V > 110)
    brown = leaf & (H >= 5) & (H < 18) & (S > 50) & (V < 170)
    dark = leaf & (V < 70)
    lesion = (brown | dark).astype(np.uint8) * 255

    n, _, stats, _ = cv2.connectedComponentsWithStats(lesion)
    areas = stats[1:, cv2.CC_STAT_AREA] if n > 1 else np.array([], int)
    small = areas[(areas >= 15) & (areas <= 0.05 * area)]   # discrete spots, not whole-leaf scorch
    return {
        "yellow_fraction": float(yellow.sum() / area),
        "brown_fraction": float((brown | dark).sum() / area),
        "spot_fraction": float(small.sum() / area),
        "spot_count": int(len(small)),
        "leaf_area_fraction": float(leaf.mean()),
    }


def feature_vector(bgr: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """~60-D vector: HSV histograms, Lab stats, edge density, Laplacian variance, symptom fractions."""
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    lab = cv2.cvtColor(bgr, cv2.COLOR_BGR2LAB)
    m = mask
    feats = []
    for ch, rng_, bins in ((0, [0, 180], 18), (1, [0, 256], 8), (2, [0, 256], 8)):
        hist = cv2.calcHist([hsv], [ch], m, [bins], rng_).ravel()
        feats.extend(hist / max(hist.sum(), 1))
    leaf = m > 0
    for c in range(3):
        vals = lab[..., c][leaf]
        feats.extend([vals.mean(), vals.std()] if vals.size else [0, 0])
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 80, 160)
    feats.append(float((edges[leaf] > 0).mean()) if leaf.any() else 0.0)
    feats.append(float(cv2.Laplacian(gray, cv2.CV_64F)[leaf].var()) / 1000.0 if leaf.any() else 0.0)
    s = symptom_fractions(bgr, m)
    feats.extend([s["yellow_fraction"], s["brown_fraction"], s["spot_fraction"], s["spot_count"] / 50.0])
    return np.asarray(feats, dtype=np.float32)


def analyse_image(path_or_array) -> dict:
    """One call: load -> segment -> symptoms + feature vector."""
    bgr = load_image(path_or_array)
    mask, bbox = segment_leaf(bgr)
    return {"bgr": bgr, "mask": mask, "bbox": bbox,
            "symptoms": symptom_fractions(bgr, mask), "features": feature_vector(bgr, mask)}

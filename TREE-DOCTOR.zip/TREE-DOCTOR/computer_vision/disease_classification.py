"""
disease_classification.py - leaf disease / symptom classification.

Two modes
    1. TRAINED  : RandomForest on handcrafted features (image_processing.feature_vector) using an
                  image-folder dataset, e.g. PlantVillage  (datasets/plantvillage/<class_name>/*.jpg).
                  Reports accuracy, precision, recall, F1 + confusion matrix on a held-out split.
    2. SYMPTOM  : if no trained model exists, falls back to a rule-based symptom classifier
                  (healthy / chlorosis / necrosis / leaf_spot) from HSV symptom fractions.

Usage (from repo root)
    python computer_vision/disease_classification.py train --data datasets/plantvillage --per-class 150
    python computer_vision/disease_classification.py predict path/to/leaf.jpg

Only metrics printed by the `train` command are real measurements - never quote others.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from computer_vision.image_processing import analyse_image  # noqa: E402

MODEL_PATH = Path(__file__).resolve().parents[1] / "results" / "leaf_model.joblib"


# ------------------------------------------------------------------ symptom fallback ----
def classify_symptoms(symptoms: dict) -> dict:
    """Rule-based fallback. Returns {label, confidence, symptoms, source}."""
    y, b, s, n = (symptoms["yellow_fraction"], symptoms["brown_fraction"],
                  symptoms["spot_fraction"], symptoms["spot_count"])
    # thresholds match agentic_ai.decision_engine.evidence_from_leaf so both layers agree
    if s > 0.02 or n >= 5:
        label, margin = "leaf_spot", max(s / 0.02, n / 5.0)
    elif b > 0.10:
        label, margin = "necrosis", b / 0.10
    elif y > 0.15:
        label, margin = "chlorosis", y / 0.15
    else:
        label, margin = "healthy", 1.0 + (0.15 - y) / 0.15
    conf = float(min(0.95, 0.5 + 0.25 * margin))
    return {"label": label, "confidence": conf, "symptoms": symptoms, "source": "rules"}


# ------------------------------------------------------------------ trained model -------
def _load_dataset(root: Path, per_class: int, seed: int = 0):
    rng = np.random.default_rng(seed)
    X, y, names = [], [], sorted(p.name for p in root.iterdir() if p.is_dir())
    for ci, cname in enumerate(names):
        files = [p for p in (root / cname).iterdir() if p.suffix.lower() in {".jpg", ".jpeg", ".png"}]
        rng.shuffle(files)
        for f in files[:per_class]:
            try:
                X.append(analyse_image(f)["features"])
                y.append(ci)
            except Exception as e:  # unreadable image
                print("skip", f, e)
    return np.vstack(X), np.asarray(y), names


def train(data_dir: str, per_class: int = 150, out: Path = MODEL_PATH) -> dict:
    import joblib
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                                 precision_recall_fscore_support)
    from sklearn.model_selection import train_test_split

    X, y, names = _load_dataset(Path(data_dir), per_class)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.25, stratify=y, random_state=0)
    clf = RandomForestClassifier(n_estimators=300, random_state=0, n_jobs=-1).fit(Xtr, ytr)
    pred = clf.predict(Xte)
    p, r, f1, _ = precision_recall_fscore_support(yte, pred, average="macro", zero_division=0)
    metrics = {"n_train": int(len(ytr)), "n_test": int(len(yte)), "classes": names,
               "accuracy": float(accuracy_score(yte, pred)),
               "precision_macro": float(p), "recall_macro": float(r), "f1_macro": float(f1)}
    print(classification_report(yte, pred, target_names=names, zero_division=0))
    out.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump({"model": clf, "classes": names}, out)
    (out.parent / "leaf_metrics.json").write_text(json.dumps(metrics, indent=2))
    cm = confusion_matrix(yte, pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.imshow(cm, cmap="Greens")
    ax.set_xticks(range(len(names)), names, rotation=90, fontsize=6)
    ax.set_yticks(range(len(names)), names, fontsize=6)
    ax.set_title("Leaf classifier - confusion matrix (held-out)")
    fig.tight_layout()
    (out.parent / "graphs").mkdir(exist_ok=True)
    fig.savefig(out.parent / "graphs" / "leaf_confusion_matrix.png", dpi=150)
    print(json.dumps(metrics, indent=2))
    return metrics


def predict(path_or_array, model_path: Path = MODEL_PATH) -> dict:
    """Classify one leaf image. Uses trained model if present, else symptom rules."""
    a = analyse_image(path_or_array)
    if Path(model_path).exists():
        import joblib
        bundle = joblib.load(model_path)
        proba = bundle["model"].predict_proba(a["features"].reshape(1, -1))[0]
        i = int(np.argmax(proba))
        return {"label": bundle["classes"][i], "confidence": float(proba[i]),
                "symptoms": a["symptoms"], "source": "random_forest"}
    return classify_symptoms(a["symptoms"])


if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "train":
        pc = int(sys.argv[sys.argv.index("--per-class") + 1]) if "--per-class" in sys.argv else 150
        train(sys.argv[sys.argv.index("--data") + 1] if "--data" in sys.argv else sys.argv[2], pc)
    elif len(sys.argv) >= 3 and sys.argv[1] == "predict":
        print(json.dumps(predict(sys.argv[2]), indent=2))
    else:
        print(__doc__)

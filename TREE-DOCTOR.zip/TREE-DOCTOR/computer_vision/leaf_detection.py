"""
leaf_detection.py - isolates the leaf from its background so symptoms are measured on leaf pixels only.

Method (classical, no training needed):
    1. Excess-Green index ExG = 2G - R - B (plus HSV colour range for yellowing/browning leaf tissue)
    2. Otsu threshold on ExG, OR'd with an HSV 'leaf-coloured' range
    3. Morphological open/close, keep the largest connected component
"""
from __future__ import annotations

import cv2
import numpy as np


def load_image(path_or_array, max_side: int = 512) -> np.ndarray:
    img = cv2.imread(str(path_or_array)) if not isinstance(path_or_array, np.ndarray) else path_or_array
    if img is None:
        raise ValueError(f"Could not read image: {path_or_array}")
    h, w = img.shape[:2]
    scale = max_side / max(h, w)
    return cv2.resize(img, (int(w * scale), int(h * scale))) if scale < 1 else img


def segment_leaf(bgr: np.ndarray) -> tuple[np.ndarray, tuple[int, int, int, int]]:
    """Return (binary_mask uint8 0/255, bbox x,y,w,h). Falls back to the full frame if nothing found."""
    b, g, r = [c.astype(np.float32) for c in cv2.split(bgr)]
    exg = np.clip(2 * g - r - b, 0, None)
    exg8 = cv2.normalize(exg, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
    _, m_exg = cv2.threshold(exg8, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    # green..yellow..brown leaf tissue; excludes very low saturation (white/grey background)
    m_hsv = cv2.inRange(hsv, (8, 60, 30), (95, 255, 255))
    mask = cv2.bitwise_or(m_exg, m_hsv)

    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k)
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k)

    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask)
    if n <= 1:
        h, w = bgr.shape[:2]
        return np.full((h, w), 255, np.uint8), (0, 0, w, h)
    idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    leaf = (labels == idx).astype(np.uint8) * 255
    # fill holes (lesions inside the leaf must stay in the mask)
    cnts, _ = cv2.findContours(leaf, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    filled = np.zeros_like(leaf)
    cv2.drawContours(filled, cnts, -1, 255, thickness=cv2.FILLED)
    x, y, w, h = cv2.boundingRect(filled)
    return filled, (x, y, w, h)


if __name__ == "__main__":
    import sys
    img = load_image(sys.argv[1])
    mask, bbox = segment_leaf(img)
    out = cv2.bitwise_and(img, img, mask=mask)
    cv2.imwrite(sys.argv[2] if len(sys.argv) > 2 else "leaf_segmented.png", out)
    print("bbox:", bbox, "leaf area fraction:", round(float((mask > 0).mean()), 3))

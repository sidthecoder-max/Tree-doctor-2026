"""
diagnosis_agent.py - the Tree Doctor agent loop.

    OBSERVE   sensor features (from signal processing) + any leaf analysis so far
    REASON    update belief over hypotheses (decision_engine.posterior)
    DECIDE    finalize?  or choose the observation with the highest expected information gain
    ACT       call a tool: request_resample (poor data quality) / request_leaf_image (resolve ambiguity)
    ADAPT     long-term memory: if the previous recommendation was "irrigate" and soil did not respond,
              that becomes new evidence ("irrigation_ineffective") and shifts belief toward sensor/system fault

This is NOT a single classification: the number of steps and the tools called depend on what the agent
observes. Tools are injected so the loop is testable without hardware or a camera.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional

from agentic_ai.decision_engine import (HYPOTHESES, best_next_observation, evidence_from_features,
                                        evidence_from_leaf, posterior, EVIDENCE_SOURCE)
from agentic_ai.recommendations import build_recommendations, explain

CONFIDENCE_TARGET = 0.70
MIN_GAIN_BITS = 0.05
MAX_STEPS = 5


@dataclass
class Tools:
    """Callables the agent may invoke. Any may be None (tool unavailable)."""
    request_resample: Optional[Callable[[], dict]] = None     # -> fresh features dict
    request_leaf_image: Optional[Callable[[], Optional[dict]]] = None  # -> leaf dict or None


@dataclass
class DiagnosisAgent:
    tools: Tools = field(default_factory=Tools)
    memory: list = field(default_factory=list)   # previous episodes

    # ------------------------------------------------------------------ adaptation ----
    def _memory_evidence(self, features: dict) -> dict:
        """Check whether the last recommended watering actually changed soil moisture."""
        if not self.memory:
            return {}
        last = self.memory[-1]
        asked_water = any("irrigat" in r["action"].lower() for r in last["recommendations"])
        if asked_water and features["n_samples"] > last["n_samples"]:
            rose = features["soil_now"] - last["soil_now"]
            return {"irrigation_ineffective": bool(rose < 5.0)}
        return {}

    # ----------------------------------------------------------------------- run ------
    def run(self, features: dict, leaf: Optional[dict] = None) -> dict:
        trace: list[dict] = []
        evidence = {**evidence_from_features(features), **evidence_from_leaf(leaf),
                    **self._memory_evidence(features)}
        resampled = False

        for step in range(1, MAX_STEPS + 1):
            post = posterior(evidence)
            top = max(post, key=post.get)
            conf = post[top]
            observed = {k: v for k, v in evidence.items() if v is not None}

            # DECIDE ---------------------------------------------------------------
            action, why = "finalize", f"confidence {conf:.0%} reached target" if conf >= CONFIDENCE_TARGET else ""
            if features.get("quality", 1.0) < 0.7 and not resampled and self.tools.request_resample:
                action, why = "request_resample", f"data quality {features['quality']:.2f} < 0.7"
            elif conf < CONFIDENCE_TARGET:
                avail = {e for e, tool in EVIDENCE_SOURCE.items()
                         if getattr(self.tools, tool, None) is not None and evidence.get(e) is None}
                name, gain = best_next_observation(evidence, avail or None) if avail else (None, 0.0)
                if name and gain >= MIN_GAIN_BITS:
                    action, why = EVIDENCE_SOURCE[name], f"most informative missing evidence: {name} (+{gain:.2f} bits)"
                else:
                    why = f"confidence {conf:.0%} below target but no useful observation available"
            trace.append({"step": step, "belief_top": top, "confidence": round(conf, 3),
                          "observed": observed, "action": action, "why": why})

            # ACT -------------------------------------------------------------------
            if action == "finalize":
                break
            if action == "request_resample":
                resampled = True
                features = self.tools.request_resample()
                evidence.update(evidence_from_features(features))
            elif action == "request_leaf_image":
                leaf = self.tools.request_leaf_image()
                new = evidence_from_leaf(leaf)
                if leaf is None:                      # user/camera gave nothing: mark as tried
                    self.tools = Tools(self.tools.request_resample, None)
                else:
                    evidence.update(new)

        post = posterior(evidence)
        top = max(post, key=post.get)
        conf = post[top]
        needs_human = conf < CONFIDENCE_TARGET
        recs = build_recommendations(top, features, conf, needs_human)
        if evidence.get("irrigation_ineffective"):       # ADAPT: last advice had no measurable effect
            recs.insert(0, {"action": "Previous watering advice did not raise soil moisture - check emitter, valve "
                                      "and probe contact before irrigating again.", "urgency": "high"})
        result = {"diagnosis": top, "confidence": conf, "posterior": post, "evidence": evidence,
                  "trace": trace, "recommendations": recs, "needs_human": needs_human,
                  "features": features}
        result["explanation"] = explain(result)
        self.memory.append({"diagnosis": top, "recommendations": recs, "soil_now": features["soil_now"],
                            "n_samples": features["n_samples"]})
        return result

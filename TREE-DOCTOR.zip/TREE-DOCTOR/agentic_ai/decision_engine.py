"""
decision_engine.py - probabilistic reasoning core of the Tree Doctor agent.

Model: a naive-Bayes belief over tree-condition hypotheses, updated from *observed* evidence only.
Unobserved evidence (e.g. no leaf photo yet) is simply left out, which lets the agent reason about
WHAT IT DOES NOT KNOW: `best_next_observation()` computes the expected entropy reduction
(information gain) of every missing piece of evidence, so the agent can decide to go and get it.

The prior / likelihood numbers below are EXPERT-SET ASSUMPTIONS, not fitted to field data.
They are exposed in one table so they can be inspected, challenged and re-estimated.
"""
from __future__ import annotations

import math

HYPOTHESES = ["healthy", "drought_stress", "overwatering", "fungal_disease", "bacterial_disease",
              "viral_disease", "nutrient_deficiency", "heat_stress", "sensor_fault"]

PRIOR = dict(healthy=.35, drought_stress=.15, overwatering=.10, fungal_disease=.10, bacterial_disease=.05,
             viral_disease=.04, nutrient_deficiency=.08, heat_stress=.08, sensor_fault=.05)

# P(evidence = True | hypothesis)
_L = {
    #                   heal  drgt  over  fung  bact  vir   nutr  heat  sens
    "soil_dry":        [.08, .90, .03, .15, .15, .10, .15, .50, .30],
    "soil_wet":        [.10, .02, .90, .35, .30, .10, .10, .02, .30],
    "hum_high":        [.15, .05, .30, .70, .50, .15, .15, .05, .15],
    "temp_high":       [.10, .40, .10, .10, .15, .15, .10, .90, .15],
    "sensor_flatline": [.02, .02, .02, .02, .02, .02, .02, .02, .80],
    "irrigation_ineffective": [.03, .10, .03, .03, .03, .03, .03, .03, .80],
    "leaf_spots":      [.03, .05, .15, .80, .75, .20, .10, .10, .10],
    "leaf_yellow":     [.05, .30, .60, .30, .30, .70, .85, .20, .10],
    "leaf_brown":      [.03, .60, .20, .40, .40, .15, .30, .75, .05],
}
LIK = {e: dict(zip(HYPOTHESES, v)) for e, v in _L.items()}

# Which tool must be called to observe each evidence variable
EVIDENCE_SOURCE = {"leaf_spots": "request_leaf_image", "leaf_yellow": "request_leaf_image",
                   "leaf_brown": "request_leaf_image"}


def entropy(post: dict) -> float:
    return -sum(p * math.log2(p) for p in post.values() if p > 0)


def posterior(evidence: dict) -> dict:
    """evidence: {name: True/False/None}. None => unobserved (skipped)."""
    logp = {h: math.log(PRIOR[h]) for h in HYPOTHESES}
    for e, val in evidence.items():
        if val is None or e not in LIK:
            continue
        for h in HYPOTHESES:
            p = LIK[e][h]
            logp[h] += math.log(p if val else 1 - p)
    m = max(logp.values())
    w = {h: math.exp(v - m) for h, v in logp.items()}
    z = sum(w.values())
    return {h: v / z for h, v in w.items()}


def information_gain(evidence: dict, name: str) -> float:
    """Expected entropy reduction (bits) from observing evidence variable `name`."""
    post = posterior(evidence)
    p_true = sum(post[h] * LIK[name][h] for h in HYPOTHESES)
    h0 = entropy(post)
    exp_h = 0.0
    for val, pv in ((True, p_true), (False, 1 - p_true)):
        if pv <= 1e-12:
            continue
        exp_h += pv * entropy(posterior({**evidence, name: val}))
    return h0 - exp_h


def best_next_observation(evidence: dict, available: set[str] | None = None):
    """Return (evidence_name, gain_bits) maximising information gain among unobserved variables."""
    best = (None, 0.0)
    for name in LIK:
        if evidence.get(name) is not None:
            continue
        if available is not None and name not in available:
            continue
        g = information_gain(evidence, name)
        if g > best[1]:
            best = (name, g)
    return best


# ------------------------------------------------------------- evidence extraction -----
def evidence_from_features(f: dict) -> dict:
    """Signal-processing features -> boolean evidence (None when not computable)."""
    def b(cond, *vals):
        return None if any(v != v for v in vals) else bool(cond)  # NaN check
    return {
        "soil_dry": b(f["soil_now"] < 25.0, f["soil_now"]),
        "soil_wet": b(f["soil_now"] > 75.0 or f["hours_above_wet"] > 12, f["soil_now"]),
        "hum_high": b(f["hum_mean_24h"] > 80.0, f["hum_mean_24h"]),
        "temp_high": b(f["temp_max_24h"] > 36.0, f["temp_max_24h"]),
        "sensor_flatline": bool(f.get("flatline", False)),
    }


def evidence_from_leaf(leaf: dict | None) -> dict:
    """Vision output -> boolean evidence. All None when no image has been analysed."""
    if leaf is None:
        return {"leaf_spots": None, "leaf_yellow": None, "leaf_brown": None}
    s, label = leaf["symptoms"], str(leaf["label"]).lower()
    spots = s["spot_fraction"] > 0.02 or s["spot_count"] >= 5
    yellow = s["yellow_fraction"] > 0.15
    brown = s["brown_fraction"] > 0.10
    if leaf.get("confidence", 0) >= 0.6 and leaf.get("source") == "random_forest":
        if any(k in label for k in ("spot", "blight", "rust", "mold", "mildew", "scab", "rot", "bacterial")):
            spots = True
        if any(k in label for k in ("virus", "yellow", "curl", "mosaic")):
            yellow = True
    if label == "chlorosis":
        yellow = True
    if label == "necrosis":
        brown = True
    if label == "leaf_spot":
        spots = True
    return {"leaf_spots": spots, "leaf_yellow": yellow, "leaf_brown": brown}

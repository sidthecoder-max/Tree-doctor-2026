"""
recommendations.py - turns a diagnosis into context-aware actions and a plain-language explanation.

Recommendations are rule-based and deterministic (auditable). An LLM may OPTIONALLY be used only to
phrase the final explanation (set ANTHROPIC_API_KEY); it never decides the diagnosis.
"""
from __future__ import annotations

import os

BASE_ACTIONS = {
    "healthy": [("Continue current watering schedule; keep monitoring.", "low")],
    "drought_stress": [("Irrigate deeply at the root zone.", "high"),
                       ("Add mulch to reduce evaporation.", "medium")],
    "overwatering": [("Pause irrigation until soil moisture falls below 60%.", "high"),
                     ("Check drainage / compaction around the root zone.", "medium")],
    "fungal_disease": [("Remove and bag affected leaves; do not compost.", "high"),
                       ("Improve airflow; avoid overhead watering; consider an approved fungicide.", "medium")],
    "bacterial_disease": [("Isolate / prune affected branches with sterilised tools.", "high"),
                          ("Avoid working on the tree when foliage is wet.", "medium")],
    "viral_disease": [("Confirm with a local plant-pathology lab; viral infections have no cure.", "high"),
                      ("Control insect vectors (aphids, whitefly).", "medium")],
    "nutrient_deficiency": [("Run a soil test (N, Fe, Mg) before fertilising.", "medium"),
                            ("Apply balanced fertiliser according to test results.", "medium")],
    "heat_stress": [("Provide shade or temporary cover during the afternoon peak.", "high"),
                    ("Water early morning or evening.", "medium")],
    "sensor_fault": [("Inspect probe wiring and placement; re-seat the soil probe.", "high"),
                     ("Cross-check against a manual probe or the finger test; recalibrate if needed.", "high")],
}


def build_recommendations(diagnosis: str, features: dict, confidence: float, needs_human: bool) -> list[dict]:
    """Return list of {action, urgency}. Context from sensor features adjusts timing/urgency."""
    recs = [{"action": a, "urgency": u} for a, u in BASE_ACTIONS.get(diagnosis, [])]
    htd = features.get("hours_to_dry", float("nan"))
    if diagnosis == "healthy" and htd == htd and htd < 12:
        recs.insert(0, {"action": f"Soil projected to reach the dry threshold in ~{htd:.0f} h - plan irrigation.",
                        "urgency": "medium"})
    if diagnosis == "drought_stress" and htd == htd:
        recs[0]["action"] += f" (soil already {features['soil_now']:.0f}%)"
    if diagnosis in ("drought_stress", "heat_stress") and features.get("hours_since_irrigation", float("nan")) == \
            features.get("hours_since_irrigation", float("nan")):
        recs.append({"action": f"Last watering detected {features['hours_since_irrigation']:.0f} h ago.",
                     "urgency": "info"})
    if needs_human:
        recs.insert(0, {"action": f"Confidence only {confidence:.0%}: inspect the tree manually before acting.",
                        "urgency": "high"})
    return recs


def explain(result: dict, use_llm: bool = False) -> str:
    """Plain-language explanation. Template by default; optional LLM rewording."""
    top = sorted(result["posterior"].items(), key=lambda kv: -kv[1])[:3]
    base = (f"Diagnosis: {result['diagnosis'].replace('_', ' ')} ({result['confidence']:.0%} confidence). "
            f"Alternatives: " + ", ".join(f"{k.replace('_', ' ')} {v:.0%}" for k, v in top[1:]) + ". "
            f"Reasoning used {len(result['trace'])} steps"
            + (" including a follow-up observation." if any(s['action'] != 'finalize' for s in result['trace']) else "."))
    if use_llm:
        txt = _llm_rewrite(base, result)
        if txt:
            return txt
    return base


def _llm_rewrite(base: str, result: dict) -> str | None:
    """Optional. Disclosed in README. Returns None if no key / any failure."""
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return None
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=key)
        msg = client.messages.create(
            model=os.getenv("LLM_MODEL", "claude-sonnet-5-5"), max_tokens=200,
            messages=[{"role": "user", "content":
                       "Rewrite this tree-health finding for a farmer in 3 short sentences, adding no new facts:\n"
                       + base + "\nRecommendations: " + "; ".join(r["action"] for r in result["recommendations"])}])
        return msg.content[0].text
    except Exception:
        return None
